
package jarquin;

// Clase del producto
public class Burguer {
    private String pan = "";
    private String salsa = "";
    private String carne = "";
    
    public void setPan(String pan){
        this.pan = pan;
    }
    public void setSalsa(String salsa){
        this.salsa = salsa;
    }
    public void setCarne(String carne){
        this.carne = carne;
    } 

    @Override
    public String toString() {
        return "Burguer{" + "pan=" + pan + ", salsa=" + salsa + ", carne=" + carne + '}';
    }
    
    
}
