/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jarquin;

public class BurguerBaconBuilder extends BurguerBuilder{
    public void buildPan(){
        burguer.setPan("Tostado");
    }
    public void buildSalsa(){
        burguer.setSalsa("Queso");
    }
    public void buildCarne(){
        burguer.setCarne("Tocino+BBQ");
    }
    
}
