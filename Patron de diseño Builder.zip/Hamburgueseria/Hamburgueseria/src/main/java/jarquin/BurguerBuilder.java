/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package jarquin;

//Constructor abstracto
public abstract class BurguerBuilder {
    protected Burguer burguer;
    
    public Burguer getBurguer(){
        return burguer;
    }
    public void crearNuevaBurguer(){
        burguer = new Burguer();
    }

    public abstract void buildPan();
    public abstract void buildSalsa();
    public abstract void buildCarne();
    
    
    
    }
