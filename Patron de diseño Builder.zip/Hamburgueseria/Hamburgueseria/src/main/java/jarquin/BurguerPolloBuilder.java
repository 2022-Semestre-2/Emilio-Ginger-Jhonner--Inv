/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jarquin;

public class BurguerPolloBuilder extends BurguerBuilder {
    public void buildPan(){
        burguer.setPan("Ajonjoli");
    }
    public void buildSalsa(){
        burguer.setSalsa("Blanca");
    }
    public void buildCarne(){
        burguer.setCarne("Pollo empanizado");
    }
}
