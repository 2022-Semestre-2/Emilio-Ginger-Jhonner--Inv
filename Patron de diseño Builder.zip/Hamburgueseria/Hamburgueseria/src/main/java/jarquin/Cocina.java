


package jarquin;

// CLASE DIRECTOR
public class Cocina {
    private BurguerBuilder burguerBuilder;
    
    public void setBurguerBuilder(BurguerBuilder bb){
        burguerBuilder = bb;
    }
    
    public Burguer getBurguer(){
        return burguerBuilder.getBurguer();
    }
    
    public void construirBurguer(){
        burguerBuilder.crearNuevaBurguer();
        burguerBuilder.buildPan();
        burguerBuilder.buildSalsa();
        burguerBuilder.buildCarne();
    } 
}
