

package principal;

import jarquin.Cocina;
import jarquin.BurguerPolloBuilder;
import jarquin.BurguerBuilder;
import jarquin.Burguer;
import jarquin.BurguerBaconBuilder;
public class Principal {
    
    /**
     *
     * @param args
     */
    public static void main(String[] args){
        Cocina cocina = new Cocina(); // Director
        BurguerBuilder Hamburguesa_Pollo = new BurguerPolloBuilder();
        BurguerBuilder Hamburgesa_Tocino = new BurguerBaconBuilder();
        
        cocina.setBurguerBuilder(Hamburguesa_Pollo);
        cocina.construirBurguer();
        
        Burguer burguer = cocina.getBurguer();
        System.out.print(burguer.toString());
    }
}
